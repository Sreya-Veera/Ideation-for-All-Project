import { useState } from "react";

type View = "home" | "dashboard" | "create" | "join" | "board";

const cards = [
  ["spin up a board", "Make a board for your class or team in seconds and share one short code.", "yellow"],
  ["jump in with a code", "Got a code? Pop it in and you’re on the board with everyone else.", "blue"],
  ["color-code the vibe", "Five note colors so urgent ideas pop and themes stay easy to spot.", "pink"],
  ["stack similar ideas", "Group notes that go together and give each group a title.", "lime"],
  ["vote it up (or down)", "One vote each. Sort by votes to see what the group actually wants.", "purple"],
  ["private and saved", "Invite-only boards for your group, and every note, group and vote autosaves.", "white"],
];

const notes = [
  ["daily stand-up but everyone is right on time", "yellow", 5],
  ["redesign the new hire welcome deck", "pink", 4],
  ["pair program from the rooftop", "pink", 3],
  ["weird internal team titles", "lime", 3],
  ["open on a shared code style guide", "blue", 2],
  ["cancel the board for a coffee", "yellow", 2],
];

function Brand() {
  return (
    <button className="brand" onClick={() => location.reload()} aria-label="Ideation for all home">
      <span className="brand-mark">
        <i />
        <i />
        <i />
      </span>
      <b>ideation for all</b>
    </button>
  );
}

function Header({ navigate }: { navigate: (view: View) => void }) {
  return (
    <>
      <div className="ticker">
        <span>ELEPHANT PROPERTY</span>
        <span>IDEATION FOR ALL</span>
        <span>NOTHING HAS TO SUCK</span>
      </div>
      <header>
        <Brand />
        <nav>
          <button onClick={() => navigate("home")}>features</button>
          <button onClick={() => navigate("create")}>how it works</button>
          <button onClick={() => navigate("join")}>who it’s for</button>
        </nav>
        <div className="header-actions">
          <button onClick={() => navigate("dashboard")}>log in</button>
          <button className="pill dark" onClick={() => navigate("create")}>
            get started
          </button>
        </div>
      </header>
    </>
  );
}

function Footer({ navigate }: { navigate: (view: View) => void }) {
  return (
    <footer>
      <span>Ideation for all · UNT Senior Capstone · Team Powerpuff Girls</span>
      <div>
        <button onClick={() => navigate("home")}>features</button>
        <button onClick={() => navigate("create")}>how it works</button>
        <button onClick={() => navigate("dashboard")}>log in</button>
      </div>
    </footer>
  );
}

function DemoBoard() {
  return (
    <div className="demo-shell">
      <div className="demo-head">
        <b>class brainstorm: week 5</b>
        <span>
          <i className="live-dot" /> 12 here now
        </span>
      </div>
      <div className="demo-grid">
        <div className="demo-column solid">
          <b>top picks</b>
          <MiniNote color="yellow" text="field trip to the science museum" votes="9" />
          <MiniNote color="lime" text="class garden project" votes="6" />
        </div>
        <div className="demo-column dashed">
          <b>new ideas</b>
          <MiniNote color="pink" text="podcast episode about our town" votes="2" />
          <MiniNote color="blue" text="design our own board game" votes="1" />
        </div>
      </div>
    </div>
  );
}

function MiniNote({ color, text, votes }: { color: string; text: string; votes: string }) {
  return (
    <div className={`mini-note ${color}`}>
      <span>{text}</span>
      <b>▲ {votes}</b>
    </div>
  );
}

function Home({ navigate }: { navigate: (view: View) => void }) {
  return (
    <>
      <Header navigate={navigate} />
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="live-label">
              <i className="live-dot" /> live, right in your browser
            </div>
            <h1>
              brainstorm
              <br />
              like it’s a
              <br />
              group chat.
            </h1>
            <p>
              One live board for the whole group. Drop sticky notes, stack the similar ones, vote the best to the
              top, and keep the results for next time.
            </p>
            <div className="hero-actions">
              <button className="pill primary" onClick={() => navigate("create")}>
                start a board <span>→</span>
              </button>
              <button className="pill light" onClick={() => navigate("join")}>
                join with a code
              </button>
            </div>
            <small>no download. just open the site and go.</small>
          </div>
          <DemoBoard />
        </section>

        <div className="feature-strip">
          {["works in any browser", "no app to download", "real-time", "private boards", "autosaves"].map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>

        <section className="features">
          <h2>
            everything a sticky wall
            <br />
            does. minus the mess.
          </h2>
          <div className="feature-grid">
            {cards.map(([title, description, color]) => (
              <article className={`feature-card ${color}`} key={title}>
                <h3>{title}</h3>
                <p>{description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="how">
          <h2>how it works</h2>
          <div className="steps">
            {[
              ["1", "start a board", "Name it, pick private or open, and your join code is ready."],
              ["2", "share the code", "Drop it in the group chat. Everyone joins from their browser."],
              ["3", "drop, stack, vote", "Add notes, group what matches, and vote the best ideas to the top, live."],
            ].map(([number, title, description], index) => (
              <div className="step" key={number}>
                <span className={`step-number n${index + 1}`}>{number}</span>
                <h3>{title}</h3>
                <p>{description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="audience">
          <h2>
            made for rooms
            <br />
            full of ideas
          </h2>
          <div className="audience-grid">
            <article>
              <span className="tag yellow">classrooms &amp; training</span>
              <h3>every student gets a voice</h3>
              <p>Teachers open a board, students add and sort ideas, and the class votes on what to explore next.</p>
            </article>
            <article>
              <span className="tag blue">workplace teams</span>
              <h3>meetings that end with a plan</h3>
              <p>Group similar ideas, vote on priorities, and come back to the saved board when it’s time to follow up.</p>
            </article>
          </div>
        </section>

        <section className="cta">
          <h2>
            your next
            <br />
            brainstorm
            <br />
            starts here.
          </h2>
          <button className="pill dark" onClick={() => navigate("create")}>
            get started →
          </button>
        </section>
      </main>
      <Footer navigate={navigate} />
    </>
  );
}

function AppHeader({ navigate }: { navigate: (view: View) => void }) {
  return (
    <>
      <div className="ticker app-ticker">
        <span>ELEPHANT PROPERTY</span>
        <span>IDEATION FOR ALL</span>
        <span>NOTHING HAS TO SUCK</span>
      </div>
      <header className="app-header">
        <Brand />
        <button className="user-link" onClick={() => navigate("dashboard")}>
          sign out <span className="avatar">AP</span>
        </button>
      </header>
    </>
  );
}

function Dashboard({ navigate }: { navigate: (view: View) => void }) {
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="dashboard">
        <h1>what are we cooking up?</h1>
        <div className="quick-actions">
          <button className="quick lime" onClick={() => navigate("create")}>
            <b>＋</b>
            <span>
              <strong>start a board</strong>
              <small>make something new for the crew</small>
            </span>
          </button>
          <button className="quick purple" onClick={() => navigate("join")}>
            <b>⌁</b>
            <span>
              <strong>join with a code</strong>
              <small>someone sent you a code? pop it in</small>
            </span>
          </button>
        </div>
        <h3 className="section-label">your boards</h3>
        <div className="board-list">
          {[
            ["sprint 1 retro", "yellow", "4 members · private"],
            ["capstone feature ideas", "blue", "3 members · private"],
            ["class discussion: week 5", "pink", "24 members · private"],
          ].map(([title, color, meta]) => (
            <button className="board-card" key={title} onClick={() => navigate("board")}>
              <div className="paper-stack">
                <i className={color} />
                <i className="pink" />
                <i className="blue" />
              </div>
              <span className="tag">private</span>
              <strong>{title}</strong>
              <small>{meta}</small>
            </button>
          ))}
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function CreateBoard({ navigate }: { navigate: (view: View) => void }) {
  const [name, setName] = useState("");
  const [privacy, setPrivacy] = useState<"private" | "open">("private");
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="center-page">
        <button className="back" onClick={() => navigate("dashboard")}>
          ← back
        </button>
        <h1>start a board</h1>
        <div className="form-card">
          <label>
            name it
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="sprint 1 retro" />
          </label>
          <label>
            what’s it about? (optional)
            <textarea placeholder="what should people brainstorm about?" />
          </label>
          <p className="form-label">who can join?</p>
          <div className="privacy-options">
            <button className={privacy === "private" ? "active lime" : ""} onClick={() => setPrivacy("private")}>
              <b>● private</b>
              <small>invite-only and safe for your group</small>
            </button>
            <button className={privacy === "open" ? "active" : ""} onClick={() => setPrivacy("open")}>
              <b>○ open</b>
              <small>anyone with the code can join</small>
            </button>
          </div>
          <div className="code-preview">
            <b>RP7–2KM</b>
            <span>your 6-character join code (you can share it after you create it)</span>
          </div>
          <div className="form-actions">
            <button className="pill light" onClick={() => navigate("dashboard")}>
              cancel
            </button>
            <button className="pill primary" disabled={!name.trim()} onClick={() => navigate("board")}>
              create board →
            </button>
          </div>
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function Join({ navigate }: { navigate: (view: View) => void }) {
  const [code, setCode] = useState("");
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="center-page join-page">
        <button className="back" onClick={() => navigate("dashboard")}>
          ← back
        </button>
        <h1>got a code?</h1>
        <div className="join-card">
          <label>
            join code
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              maxLength={8}
              placeholder="R7P-42Q"
            />
          </label>
          <button className="pill primary" onClick={() => navigate("board")}>
            join board →
          </button>
        </div>
        <div className="help-box">
          <b>no code?</b>
          <span>
            ask the board owner · <button onClick={() => navigate("create")}>or start your own</button>
          </span>
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function Board({ navigate }: { navigate: (view: View) => void }) {
  const [localNotes, setLocalNotes] = useState(notes);
  const vote = (index: number) => {
    setLocalNotes((current) => current.map((note, i) => (i === index ? [note[0], note[1], Number(note[2]) + 1] : note)));
  };
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="board-page">
        <div className="board-title">
          <div>
            <span className="board-icon">◉</span>
            <h1>sprint 1 retro</h1>
            <span className="tag dark-tag">private</span>
          </div>
          <div className="board-tools">
            <button className="pill light" onClick={() => navigate("join")}>
              invite: RP7-2KM
            </button>
            <span className="collaborators">AP &nbsp; JL &nbsp; MS</span>
          </div>
        </div>
        <p className="board-question">what should we avoid, continue, and celebrate while we prep for the next sprint?</p>
        <div className="board-controls">
          <button className="pill primary">＋ add note</button>
          <button className="pill light">new group</button>
          <button className="pill light">sort by votes</button>
        </div>
        <div className="kanban">
          {[
            ["keep doing", "yellow"],
            ["needs work", "pink"],
            ["big wins", "blue"],
          ].map(([title, color], column) => (
            <section className="note-group" key={title}>
              <div className="group-head">
                <h2>{title}</h2>
                <span>•••</span>
              </div>
              {localNotes.slice(column * 2, column * 2 + 2).map(([text, noteColor, votes], i) => {
                const index = column * 2 + i;
                return (
                  <article className={`board-note ${noteColor}`} key={text}>
                    <p>{text}</p>
                    <div>
                      <small>someone</small>
                      <button onClick={() => vote(index)}>▲ {votes}</button>
                    </div>
                  </article>
                );
              })}
              <button className={`add-note ${color}`}>＋ add a note</button>
            </section>
          ))}
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<View>("home");
  const navigate = (next: View) => {
    setView(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (view === "dashboard") return <Dashboard navigate={navigate} />;
  if (view === "create") return <CreateBoard navigate={navigate} />;
  if (view === "join") return <Join navigate={navigate} />;
  if (view === "board") return <Board navigate={navigate} />;
  return <Home navigate={navigate} />;
}
