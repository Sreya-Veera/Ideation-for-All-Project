import { useState } from "react";

type View = "home" | "dashboard" | "create" | "join" | "board";

const cards = [
  ["spin up a board", "Make a board for your class or team in seconds and share one short code.", "yellow"],
  ["jump in with a code", "Got a code? Pop it in and you’re on the board with everyone else.", "blue"],
  ["color-code the vibe", "Five note colors so urgent ideas pop and themes stay easy to spot.", "pink"],
  ["stack similar ideas", "Group notes that go together and give each group a title.", "lime"],
  ["vote it up (or down)", "One vote each. Sort by votes to see what the group actually wants.", "purple"],
  ["private and saved", "Invite-only boards for your group, and every note, group and vote autosaves.", "white"],
];

const initialNotes = [
  { id: 1, text: "daily stand-up but everyone is right on time", color: "yellow", votes: 5, group: 1 },
  { id: 2, text: "redesign the new hire welcome deck", color: "pink", votes: 4, group: 1 },
  { id: 3, text: "pair program from the rooftop", color: "pink", votes: 3, group: 2 },
  { id: 4, text: "weird internal team titles", color: "lime", votes: 3, group: 2 },
  { id: 5, text: "open on a shared code style guide", color: "blue", votes: 2, group: 3 },
  { id: 6, text: "cancel the board for a coffee", color: "yellow", votes: 2, group: 3 },
];

const initialGroups = [
  { id: 1, title: "keep doing", color: "yellow" },
  { id: 2, title: "needs work", color: "pink" },
  { id: 3, title: "big wins", color: "blue" },
];

function Brand({ navigate }: { navigate: (view: View) => void }) {
  return (
    <button className="brand" onClick={() => navigate("home")} aria-label="Ideation for all home">
      <span className="brand-mark">
        <i />
        <i />
        <i />
      </span>
      <b>ideation for all</b>
    </button>
  );
}

function Header({
  navigate,
  scrollTo,
}: {
  navigate: (view: View) => void;
  scrollTo: (section: string) => void;
}) {
  return (
    <>
      <div className="ticker">
        <span>ELEPHANT PROPERTY</span>
        <span>IDEATION FOR ALL</span>
        <span>NOTHING HAS TO SUCK</span>
      </div>
      <header>
        <Brand navigate={navigate} />
        <nav>
          <button onClick={() => scrollTo("features")}>features</button>
          <button onClick={() => scrollTo("how-it-works")}>how it works</button>
          <button onClick={() => scrollTo("who-its-for")}>who it’s for</button>
        </nav>
        <div className="header-actions">
          <button onClick={() => navigate("dashboard")}>log in</button>
          <button className="pill dark" onClick={() => navigate("create")}>
            get started
          </button>
        </div>
      </header>
    </>
  );
}

function Footer({
  navigate,
  scrollTo,
}: {
  navigate: (view: View) => void;
  scrollTo: (section: string) => void;
}) {
  return (
    <footer>
      <span>Ideation for all · UNT Senior Capstone · Team Powerpuff Girls</span>
      <div>
        <button onClick={() => scrollTo("features")}>features</button>
        <button onClick={() => scrollTo("how-it-works")}>how it works</button>
        <button onClick={() => navigate("dashboard")}>log in</button>
      </div>
    </footer>
  );
}

function DemoBoard() {
  return (
    <div className="demo-shell">
      <div className="demo-head">
        <b>class brainstorm: week 5</b>
        <span>
          <i className="live-dot" /> 12 here now
        </span>
      </div>
      <div className="demo-grid">
        <div className="demo-column solid">
          <b>top picks</b>
          <MiniNote color="yellow" text="field trip to the science museum" votes="9" />
          <MiniNote color="lime" text="class garden project" votes="6" />
        </div>
        <div className="demo-column dashed">
          <b>new ideas</b>
          <MiniNote color="pink" text="podcast episode about our town" votes="2" />
          <MiniNote color="blue" text="design our own board game" votes="1" />
        </div>
      </div>
    </div>
  );
}

function MiniNote({ color, text, votes }: { color: string; text: string; votes: string }) {
  return (
    <div className={`mini-note ${color}`}>
      <span>{text}</span>
      <b>▲ {votes}</b>
    </div>
  );
}

function Home({ navigate }: { navigate: (view: View) => void }) {
  const scrollTo = (section: string) => {
    document.getElementById(section)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <Header navigate={navigate} scrollTo={scrollTo} />
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="live-label">
              <i className="live-dot" /> live, right in your browser
            </div>
            <h1>
              brainstorm
              <br />
              like it’s a
              <br />
              group chat.
            </h1>
            <p>
              One live board for the whole group. Drop sticky notes, stack the similar ones, vote the best to the
              top, and keep the results for next time.
            </p>
            <div className="hero-actions">
              <button className="pill primary" onClick={() => navigate("create")}>
                start a board <span>→</span>
              </button>
              <button className="pill light" onClick={() => navigate("join")}>
                join with a code
              </button>
            </div>
            <small>no download. just open the site and go.</small>
          </div>
          <DemoBoard />
        </section>

        <div className="feature-strip">
          {["works in any browser", "no app to download", "real-time", "private boards", "autosaves"].map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>

        <section className="features" id="features">
          <h2>
            everything a sticky wall
            <br />
            does. minus the mess.
          </h2>
          <div className="feature-grid">
            {cards.map(([title, description, color]) => (
              <article className={`feature-card ${color}`} key={title}>
                <h3>{title}</h3>
                <p>{description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="how" id="how-it-works">
          <h2>how it works</h2>
          <div className="steps">
            {[
              ["1", "start a board", "Name it, pick private or open, and your join code is ready."],
              ["2", "share the code", "Drop it in the group chat. Everyone joins from their browser."],
              ["3", "drop, stack, vote", "Add notes, group what matches, and vote the best ideas to the top, live."],
            ].map(([number, title, description], index) => (
              <div className="step" key={number}>
                <span className={`step-number n${index + 1}`}>{number}</span>
                <h3>{title}</h3>
                <p>{description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="audience" id="who-its-for">
          <h2>
            made for rooms
            <br />
            full of ideas
          </h2>
          <div className="audience-grid">
            <article>
              <span className="tag yellow">classrooms &amp; training</span>
              <h3>every student gets a voice</h3>
              <p>Teachers open a board, students add and sort ideas, and the class votes on what to explore next.</p>
            </article>
            <article>
              <span className="tag blue">workplace teams</span>
              <h3>meetings that end with a plan</h3>
              <p>Group similar ideas, vote on priorities, and come back to the saved board when it’s time to follow up.</p>
            </article>
          </div>
        </section>

        <section className="cta">
          <h2>
            your next
            <br />
            brainstorm
            <br />
            starts here.
          </h2>
          <button className="pill dark" onClick={() => navigate("create")}>
            get started →
          </button>
        </section>
      </main>
      <Footer navigate={navigate} scrollTo={scrollTo} />
    </>
  );
}

function AppHeader({ navigate }: { navigate: (view: View) => void }) {
  return (
    <>
      <div className="ticker app-ticker">
        <span>ELEPHANT PROPERTY</span>
        <span>IDEATION FOR ALL</span>
        <span>NOTHING HAS TO SUCK</span>
      </div>
      <header className="app-header">
        <Brand navigate={navigate} />
        <button className="user-link" onClick={() => navigate("home")}>
          sign out <span className="avatar">AP</span>
        </button>
      </header>
    </>
  );
}

function Dashboard({ navigate }: { navigate: (view: View) => void }) {
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="dashboard">
        <h1>what are we cooking up?</h1>
        <div className="quick-actions">
          <button className="quick lime" onClick={() => navigate("create")}>
            <b>＋</b>
            <span>
              <strong>start a board</strong>
              <small>make something new for the crew</small>
            </span>
          </button>
          <button className="quick purple" onClick={() => navigate("join")}>
            <b>⌁</b>
            <span>
              <strong>join with a code</strong>
              <small>someone sent you a code? pop it in</small>
            </span>
          </button>
        </div>
        <h3 className="section-label">your boards</h3>
        <div className="board-list">
          {[
            ["sprint 1 retro", "yellow", "4 members · private"],
            ["capstone feature ideas", "blue", "3 members · private"],
            ["class discussion: week 5", "pink", "24 members · private"],
          ].map(([title, color, meta]) => (
            <button className="board-card" key={title} onClick={() => navigate("board")}>
              <div className="paper-stack">
                <i className={color} />
                <i className="pink" />
                <i className="blue" />
              </div>
              <span className="tag">private</span>
              <strong>{title}</strong>
              <small>{meta}</small>
            </button>
          ))}
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function CreateBoard({ navigate }: { navigate: (view: View) => void }) {
  const [name, setName] = useState("");
  const [privacy, setPrivacy] = useState<"private" | "open">("private");
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="center-page">
        <button className="back" onClick={() => navigate("dashboard")}>
          ← back
        </button>
        <h1>start a board</h1>
        <div className="form-card">
          <label>
            name it
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="sprint 1 retro" />
          </label>
          <label>
            what’s it about? (optional)
            <textarea placeholder="what should people brainstorm about?" />
          </label>
          <p className="form-label">who can join?</p>
          <div className="privacy-options">
            <button className={privacy === "private" ? "active lime" : ""} onClick={() => setPrivacy("private")}>
              <b>● private</b>
              <small>invite-only and safe for your group</small>
            </button>
            <button className={privacy === "open" ? "active" : ""} onClick={() => setPrivacy("open")}>
              <b>○ open</b>
              <small>anyone with the code can join</small>
            </button>
          </div>
          <div className="code-preview">
            <b>RP7–2KM</b>
            <span>your 6-character join code (you can share it after you create it)</span>
          </div>
          <div className="form-actions">
            <button className="pill light" onClick={() => navigate("dashboard")}>
              cancel
            </button>
            <button className="pill primary" disabled={!name.trim()} onClick={() => navigate("board")}>
              create board →
            </button>
          </div>
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function Join({ navigate }: { navigate: (view: View) => void }) {
  const [code, setCode] = useState("");
  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="center-page join-page">
        <button className="back" onClick={() => navigate("dashboard")}>
          ← back
        </button>
        <h1>got a code?</h1>
        <div className="join-card">
          <label>
            join code
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              maxLength={8}
              placeholder="R7P-42Q"
            />
          </label>
          <button className="pill primary" onClick={() => navigate("board")}>
            join board →
          </button>
        </div>
        <div className="help-box">
          <b>no code?</b>
          <span>
            ask the board owner · <button onClick={() => navigate("create")}>or start your own</button>
          </span>
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

function Board({ navigate }: { navigate: (view: View) => void }) {
  const [localNotes, setLocalNotes] = useState(initialNotes);
  const [groups, setGroups] = useState(initialGroups);
  const [composer, setComposer] = useState<number | null>(null);
  const [draft, setDraft] = useState("");
  const [sorted, setSorted] = useState(false);
  const [copied, setCopied] = useState(false);

  const vote = (id: number) => {
    setLocalNotes((current) => current.map((note) => (note.id === id ? { ...note, votes: note.votes + 1 } : note)));
  };

  const openComposer = (group: number) => {
    setComposer(group);
    setDraft("");
  };

  const addNote = (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft.trim() || composer === null) return;
    const colors = ["yellow", "pink", "blue", "lime", "purple"];
    setLocalNotes((current) => [
      ...current,
      {
        id: Date.now(),
        text: draft.trim(),
        color: colors[current.length % colors.length],
        votes: 0,
        group: composer,
      },
    ]);
    setComposer(null);
    setDraft("");
  };

  const addGroup = () => {
    const id = Math.max(...groups.map((group) => group.id)) + 1;
    const colors = ["lime", "purple", "yellow", "pink", "blue"];
    setGroups((current) => [
      ...current,
      { id, title: `idea group ${current.length + 1}`, color: colors[current.length % colors.length] },
    ]);
    openComposer(id);
  };

  const copyInvite = async () => {
    try {
      await navigator.clipboard.writeText("RP7-2KM");
    } catch {
      // Clipboard access can be unavailable in embedded previews; the visible code remains selectable.
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="app-page">
      <AppHeader navigate={navigate} />
      <main className="board-page">
        <div className="board-title">
          <div>
            <span className="board-icon">◉</span>
            <h1>sprint 1 retro</h1>
            <span className="tag dark-tag">private</span>
          </div>
          <div className="board-tools">
            <button className="pill light" onClick={copyInvite}>
              {copied ? "code copied!" : "invite: RP7-2KM"}
            </button>
            <span className="collaborators">AP &nbsp; JL &nbsp; MS</span>
          </div>
        </div>
        <p className="board-question">what should we avoid, continue, and celebrate while we prep for the next sprint?</p>
        <div className="board-controls">
          <button className="pill primary" onClick={() => openComposer(groups[0].id)}>
            ＋ add note
          </button>
          <button className="pill light" onClick={addGroup}>
            new group
          </button>
          <button className={`pill light ${sorted ? "control-active" : ""}`} onClick={() => setSorted(!sorted)}>
            {sorted ? "sorted by votes" : "sort by votes"}
          </button>
        </div>
        <div className="kanban">
          {groups.map(({ id, title, color }) => {
            const groupNotes = localNotes.filter((note) => note.group === id);
            if (sorted) groupNotes.sort((a, b) => b.votes - a.votes);
            return (
            <section className="note-group" key={id}>
              <div className="group-head">
                <h2>{title}</h2>
                <span>{groupNotes.length} notes</span>
              </div>
              {groupNotes.map((note) => (
                  <article className={`board-note ${note.color}`} key={note.id}>
                    <p>{note.text}</p>
                    <div>
                      <small>someone</small>
                      <button onClick={() => vote(note.id)} aria-label={`Vote for ${note.text}`}>
                        ▲ {note.votes}
                      </button>
                    </div>
                  </article>
              ))}
              {composer === id && (
                <form className="note-composer" onSubmit={addNote}>
                  <textarea
                    autoFocus
                    value={draft}
                    onChange={(event) => setDraft(event.target.value)}
                    placeholder="type your idea..."
                  />
                  <div>
                    <button type="button" onClick={() => setComposer(null)}>
                      cancel
                    </button>
                    <button type="submit" disabled={!draft.trim()}>
                      add note
                    </button>
                  </div>
                </form>
              )}
              <button className={`add-note ${color}`} onClick={() => openComposer(id)}>
                ＋ add a note
              </button>
            </section>
          )})}
        </div>
      </main>
      <div className="powered">Powered by Netlify</div>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<View>("home");
  const navigate = (next: View) => {
    setView(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (view === "dashboard") return <Dashboard navigate={navigate} />;
  if (view === "create") return <CreateBoard navigate={navigate} />;
  if (view === "join") return <Join navigate={navigate} />;
  if (view === "board") return <Board navigate={navigate} />;
  return <Home navigate={navigate} />;
}
